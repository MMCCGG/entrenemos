package com.entrenemos.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RestConfiguration {
    // Aquí puedes añadir configuración global de tus controladores REST
}
