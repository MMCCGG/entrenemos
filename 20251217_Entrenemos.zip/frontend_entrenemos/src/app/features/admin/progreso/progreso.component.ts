import { Component } from '@angular/core';

@Component({
  selector: 'app-progreso',
  standalone: true,
  imports: [],
  templateUrl: './progreso.component.html',
  styleUrl: './progreso.component.css'
})
export class ProgresoComponent {

}
